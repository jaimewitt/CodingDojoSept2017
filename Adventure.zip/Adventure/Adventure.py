from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def opening():
    return render_template('open.html')

@app.route('/left')
def left():
    return render_template('left.html')

@app.route('/locked_in')
def locked_in():
   return render_template('locked_in.html')

@app.route('/red')
def red():
   return render_template('red.html')

@app.route('/black')
def black():
   return render_template('black.html')

@app.route('/hammer')
def hammer():
   return render_template('hammer.html')

@app.route('/pick')
def pick():
   return render_template('pick.html')


app.run(debug=True)
